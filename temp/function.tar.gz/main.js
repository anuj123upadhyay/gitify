import { Client, Databases, Users, Messaging, Query, ID } from 'node-appwrite';

// Initialize Appwrite client
const client = new Client()
    .setEndpoint(process.env.APPWRITE_FUNCTION_ENDPOINT || 'https://cloud.appwrite.io/v1')
    .setProject(process.env.APPWRITE_FUNCTION_PROJECT_ID)
    .setKey(process.env.APPWRITE_API_KEY);

const databases = new Databases(client);
const users = new Users(client);
const messaging = new Messaging(client);

// Database and Collection IDs
const DATABASE_ID = process.env.DATABASE_ID || 'gitify-main';
const COLLECTIONS = {
    USERS: process.env.COLLECTION_USERS || 'users',
    REPOSITORIES: process.env.COLLECTION_REPOSITORIES || 'repositories',
    NOTIFICATIONS: process.env.COLLECTION_NOTIFICATIONS || 'notifications',
    USER_ISSUE_TRACKERS: process.env.COLLECTION_USER_ISSUE_TRACKERS || 'user_issue_trackers'
};

// ============= SCALING FEATURE 1: MULTI-PAT ROUND-ROBIN MANAGER =============

class GitHubTokenManager {
    constructor(log) {
        this.log = log;
        this.tokens = this.initializeTokens();
        this.currentTokenIndex = 0;
        this.lastRotationTime = 0;
        this.rotationInterval = 60000; // 1 minute
    }

    initializeTokens() {
        const tokenEnvs = ['GITHUB_TOKEN_1', 'GITHUB_TOKEN_2', 'GITHUB_TOKEN_3', 'GITHUB_TOKEN_4', 'GITHUB_TOKEN_5', 'GITHUB_TOKEN_6'];
        const tokens = [];

        // Add primary token for backward compatibility
        if (process.env.GITHUB_TOKEN) {
            tokens.push({
                token: process.env.GITHUB_TOKEN,
                name: 'Primary Token',
                rateLimitRemaining: 5000,
                rateLimitReset: Date.now() + 3600000,
                isActive: true,
                lastUsed: null
            });
        }

        // Add additional tokens
        tokenEnvs.forEach((envName, index) => {
            const token = process.env[envName];
            if (token) {
                tokens.push({
                    token,
                    name: `Token ${index + 1}`,
                    rateLimitRemaining: 5000,
                    rateLimitReset: Date.now() + 3600000,
                    isActive: true,
                    lastUsed: null
                });
            }
        });

        if (tokens.length === 0) {
            throw new Error('No GitHub tokens found. Please set GITHUB_TOKEN or GITHUB_TOKEN_1-6 environment variables.');
        }

        this.log(`🔑 Initialized ${tokens.length} GitHub tokens for round-robin usage`);
        return tokens;
    }

    getNextToken() {
        const now = Date.now();
        
        // Auto-rotate tokens every minute or when current token is exhausted
        if (now - this.lastRotationTime > this.rotationInterval || this.getCurrentToken().rateLimitRemaining <= 10) {
            this.rotateToNextToken();
            this.lastRotationTime = now;
        }

        return this.getCurrentToken();
    }

    getCurrentToken() {
        return this.tokens[this.currentTokenIndex];
    }

    updateRateLimit(remaining, reset) {
        const current = this.getCurrentToken();
        current.rateLimitRemaining = remaining;
        current.rateLimitReset = reset;
        current.lastUsed = new Date().toISOString();
        
        // If rate limit is low, mark as inactive and rotate
        if (remaining <= 10) {
            current.isActive = false;
            this.log(`⚠️ Token ${current.name} rate limit exhausted, rotating...`);
            this.rotateToNextToken();
        }
    }

    rotateToNextToken() {
        const startIndex = this.currentTokenIndex;
        let attempts = 0;
        
        do {
            this.currentTokenIndex = (this.currentTokenIndex + 1) % this.tokens.length;
            attempts++;
            
            const token = this.tokens[this.currentTokenIndex];
            
            // Check if token is available
            if (token.rateLimitReset <= Date.now() || token.rateLimitRemaining > 10) {
                token.isActive = true;
                token.rateLimitRemaining = token.rateLimitReset <= Date.now() ? 5000 : token.rateLimitRemaining;
                this.log(`🔄 Rotated to ${token.name} (${token.rateLimitRemaining} calls remaining)`);
                return;
            }
        } while (attempts < this.tokens.length && this.currentTokenIndex !== startIndex);
        
        this.log(`⏰ All tokens exhausted. Using current token with remaining: ${this.getCurrentToken().rateLimitRemaining}`);
    }

    getStatus() {
        return this.tokens.map(token => ({
            name: token.name,
            remaining: token.rateLimitRemaining,
            resetTime: new Date(token.rateLimitReset).toISOString(),
            isActive: token.isActive,
            lastUsed: token.lastUsed
        }));
    }
}

// ============= SCALING FEATURE 2: PER-USER ISSUE TRACKING =============

class UserIssueTrackingService {
    constructor(log) {
        this.log = log;
    }

    async getOrCreateTracker(userId, repositoryId, repoOwner, repoName) {
        try {
            // Try to find existing tracker
            const response = await databases.listDocuments(
                DATABASE_ID,
                COLLECTIONS.USER_ISSUE_TRACKERS,
                [
                    Query.equal('user_id', userId),
                    Query.equal('repository_id', repositoryId)
                ]
            );

            if (response.documents.length > 0) {
                return response.documents[0];
            }

            // Create new tracker
            const newTracker = await databases.createDocument(
                DATABASE_ID,
                COLLECTIONS.USER_ISSUE_TRACKERS,
                ID.unique(),
                {
                    user_id: userId,
                    repository_id: repositoryId,
                    repo_owner: repoOwner,
                    repo_name: repoName,
                    last_issue_id: 0,
                    last_issue_created_at: new Date('1970-01-01').toISOString(),
                    last_checked_at: new Date().toISOString()
                }
            );

            this.log(`📊 Created new issue tracker for user ${userId} in ${repoOwner}/${repoName}`);
            return newTracker;
        } catch (error) {
            this.log(`❌ Error getting/creating user issue tracker: ${error.message}`);
            throw error;
        }
    }

    async updateLastSeenIssue(userId, repositoryId, issueId, createdAt) {
        try {
            const response = await databases.listDocuments(
                DATABASE_ID,
                COLLECTIONS.USER_ISSUE_TRACKERS,
                [
                    Query.equal('user_id', userId),
                    Query.equal('repository_id', repositoryId)
                ]
            );

            if (response.documents.length > 0) {
                const tracker = response.documents[0];
                await databases.updateDocument(
                    DATABASE_ID,
                    COLLECTIONS.USER_ISSUE_TRACKERS,
                    tracker.$id,
                    {
                        last_issue_id: issueId,
                        last_issue_created_at: createdAt,
                        last_checked_at: new Date().toISOString()
                    }
                );
            }
        } catch (error) {
            this.log(`❌ Error updating last seen issue: ${error.message}`);
            throw error;
        }
    }

    isNewIssueForUser(issueCreatedAt, lastSeenAt) {
        const issueDate = new Date(issueCreatedAt);
        const lastSeenDate = new Date(lastSeenAt);
        return issueDate > lastSeenDate;
    }

    getNewIssuesForUser(issues, lastSeenAt) {
        return issues.filter(issue => this.isNewIssueForUser(issue.created_at, lastSeenAt));
    }
}

// ============= ENHANCED GITHUB API WITH ROUND-ROBIN TOKENS =============

async function fetchGitHubIssues(owner, repo, since, tokenManager) {
    const url = `https://api.github.com/repos/${owner}/${repo}/issues`;
    const params = new URLSearchParams({
        state: 'open',
        sort: 'created',
        direction: 'desc',
        per_page: '30'
    });
    
    if (since) {
        params.append('since', since);
    }

    const currentToken = tokenManager.getNextToken();
    tokenManager.log(`🔗 Fetching ${owner}/${repo} issues with ${currentToken.name} (${currentToken.rateLimitRemaining} remaining)`);

    const response = await fetch(`${url}?${params}`, {
        headers: {
            'Authorization': `token ${currentToken.token}`,
            'Accept': 'application/vnd.github.v3+json',
            'User-Agent': 'Gitify-App/1.0'
        }
    });

    // Update rate limit info from response headers
    const remaining = parseInt(response.headers.get('X-RateLimit-Remaining') || '0');
    const reset = parseInt(response.headers.get('X-RateLimit-Reset') || '0') * 1000;
    tokenManager.updateRateLimit(remaining, reset);

    if (!response.ok) {
        const errorBody = await response.text();
        
        // If rate limit exceeded, try with next token
        if (response.status === 403 && remaining === 0) {
            tokenManager.log(`⚠️ Rate limit exceeded for ${currentToken.name}, trying next token...`);
            return await fetchGitHubIssues(owner, repo, since, tokenManager);
        }
        
        throw new Error(`GitHub API error: ${response.status} ${response.statusText} - ${errorBody}`);
    }

    const issues = await response.json();
    tokenManager.log(`✅ Successfully fetched ${issues.length} issues from ${owner}/${repo}`);
    return issues;
}

/**
 * Send email notification to user
 */
async function sendEmailNotification(userEmail, userName, issue, repoName) {
    const subject = `🚨 New Issue in ${repoName}: ${issue.title}`;
    
    const emailContent = `
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="utf-8">
            <title>${subject}</title>
            <style>
                body { font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; }
                .header { background: #f8fafc; padding: 20px; border-radius: 8px; margin-bottom: 20px; }
                .header h1 { color: #1e293b; margin: 0; }
                .header p { color: #64748b; margin: 10px 0 0 0; }
                .content { background: white; border: 1px solid #e2e8f0; border-radius: 8px; padding: 20px; }
                .content h2 { color: #1e293b; margin: 0 0 10px 0; }
                .content p { color: #64748b; margin: 10px 0; }
                .labels { margin: 15px 0; }
                .label { background: #3b82f6; color: white; padding: 2px 8px; border-radius: 12px; font-size: 12px; margin-right: 5px; }
                .button { background: #3b82f6; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block; }
                .footer { text-align: center; margin-top: 30px; padding: 20px; color: #94a3b8; font-size: 14px; }
            </style>
        </head>
        <body>
            <div class="header">
                <h1>🚨 New Issue Alert</h1>
                <p>Hi ${userName}, a new issue has been created in ${repoName}</p>
            </div>
            
            <div class="content">
                <h2>${issue.title}</h2>
                <p><strong>Repository:</strong> ${repoName}</p>
                <p><strong>Issue #:</strong> ${issue.number}</p>
                <p><strong>Created:</strong> ${new Date(issue.created_at).toLocaleDateString()}</p>
                <p><strong>Author:</strong> ${issue.user.login}</p>
                
                ${issue.labels && issue.labels.length > 0 ? `
                <div class="labels">
                    <strong>Labels:</strong>
                    ${issue.labels.map(label => 
                        `<span class="label" style="background-color: #${label.color};">${label.name}</span>`
                    ).join('')}
                </div>
                ` : ''}
                
                <div style="margin: 20px 0;">
                    <a href="${issue.html_url}" class="button">View Issue on GitHub →</a>
                </div>
            </div>
            
            <div class="footer">
                <p>This notification was sent by Gitify's enhanced polling system with scaling features</p>
                <p>Manage your notifications at <a href="${process.env.NEXT_PUBLIC_APP_URL || '#'}/dashboard" style="color: #3b82f6;">your dashboard</a></p>
            </div>
        </body>
        </html>
    `;

    try {
        await messaging.createEmail(
            ID.unique(),
            subject,
            emailContent,
            [], // topics
            [], // users  
            [], // targets
            [], // cc
            [], // bcc
            [], // attachments
            false, // draft
            true // html
        );
        
        return true;
        
    } catch (error) {
        console.log(`⚠️ Email notification failed: ${error.message}`);
        return false;
    }
}

/**
 * Enhanced Repository Processing with User Issue Tracking
 */
async function processRepository(repo, tokenManager, trackingService) {
    try {
        const repoName = `${repo.repo_owner}/${repo.repo_name}`;
        tokenManager.log(`🔍 Processing repository: ${repoName}`);
        
        // Get all users tracking this repository
        const usersResponse = await databases.listDocuments(
            DATABASE_ID,
            COLLECTIONS.REPOSITORIES,
            [
                Query.equal('repo_owner', repo.repo_owner),
                Query.equal('repo_name', repo.repo_name),
                Query.equal('notifications_enabled', true)
            ]
        );

        if (usersResponse.documents.length === 0) {
            return {
                success: true,
                repoName,
                newNotifications: 0,
                message: 'No users tracking this repository'
            };
        }

        tokenManager.log(`👥 Found ${usersResponse.documents.length} users tracking ${repoName}`);

        // Get or create trackers for all users
        const userTrackers = [];
        for (const userRepo of usersResponse.documents) {
            const tracker = await trackingService.getOrCreateTracker(
                userRepo.user_id,
                userRepo.$id,
                repo.repo_owner,
                repo.repo_name
            );
            userTrackers.push({ 
                userRepo, 
                tracker,
                labels: userRepo.labels ? userRepo.labels.split(',').map(l => l.trim()).filter(l => l) : []
            });
        }

        // Find the earliest "since" date from all users
        const earliestSince = userTrackers.reduce((earliest, ut) => {
            const userSince = new Date(ut.tracker.last_issue_created_at);
            return userSince < earliest ? userSince : earliest;
        }, new Date());

        // Fetch issues from GitHub with enhanced token management
        const issues = await fetchGitHubIssues(
            repo.repo_owner,
            repo.repo_name,
            earliestSince.toISOString(),
            tokenManager
        );

        if (!issues || issues.length === 0) {
            return {
                success: true,
                repoName,
                newNotifications: 0,
                message: 'No new issues found'
            };
        }

        tokenManager.log(`📋 Found ${issues.length} issues for ${repoName}`);

        let totalNotifications = 0;

        // Process each user's new issues
        for (const { userRepo, tracker, labels } of userTrackers) {
            try {
                // Get new issues for this user
                const newIssues = trackingService.getNewIssuesForUser(issues, tracker.last_issue_created_at);
                
                if (newIssues.length === 0) {
                    continue;
                }

                // Filter by labels if specified
                const filteredIssues = labels.length > 0 
                    ? newIssues.filter(issue => 
                        issue.labels && issue.labels.some(issueLabel => 
                            labels.some(userLabel => 
                                issueLabel.name.toLowerCase().includes(userLabel.toLowerCase())
                            )
                        )
                    )
                    : newIssues;

                if (filteredIssues.length === 0) {
                    tokenManager.log(`🔍 No matching issues for user ${userRepo.user_id} (label filter applied)`);
                    continue;
                }

                tokenManager.log(`🆕 Found ${filteredIssues.length} new issues for user ${userRepo.user_id}`);

                // Get user details for email notification
                const userDoc = await databases.getDocument(
                    DATABASE_ID,
                    COLLECTIONS.USERS,
                    userRepo.user_id
                );

                // Send notifications for each new issue
                for (const issue of filteredIssues) {
                    const emailSent = await sendEmailNotification(
                        userDoc.email,
                        userDoc.name,
                        issue,
                        repoName
                    );

                    // Create notification record
                    await databases.createDocument(
                        DATABASE_ID,
                        COLLECTIONS.NOTIFICATIONS,
                        ID.unique(),
                        {
                            user_id: userRepo.user_id,
                            repository_id: userRepo.$id,
                            issue_id: issue.id,
                            issue_title: issue.title,
                            issue_url: issue.html_url,
                            issue_labels: issue.labels ? issue.labels.map(l => l.name) : [],
                            sent_at: new Date().toISOString(),
                            email_status: emailSent ? 'sent' : 'failed'
                        }
                    );

                    totalNotifications++;
                }

                // Update tracker with latest issue
                if (newIssues.length > 0) {
                    const latestIssue = newIssues[0]; // Issues are sorted by creation date desc
                    await trackingService.updateLastSeenIssue(
                        userRepo.user_id,
                        userRepo.$id,
                        latestIssue.id,
                        latestIssue.created_at
                    );
                }

            } catch (error) {
                tokenManager.log(`❌ Error processing user ${userRepo.user_id}: ${error.message}`);
            }
        }

        return {
            success: true,
            repoName,
            newNotifications: totalNotifications,
            totalIssues: issues.length,
            usersProcessed: userTrackers.length
        };

    } catch (error) {
        tokenManager.log(`❌ Error processing repository ${repo.repo_owner}/${repo.repo_name}: ${error.message}`);
        return {
            success: false,
            repoName: `${repo.repo_owner}/${repo.repo_name}`,
            error: error.message
        };
    }
}

/**
 * Enhanced Main Function with Scaling Features
 */
export default async ({ req, res, log, error }) => {
    const startTime = Date.now();
    
    try {
        log('🚀 Starting Enhanced GitHub Issue Polling with Scaling Features...');
        
        // Initialize scaling services
        const tokenManager = new GitHubTokenManager(log);
        const trackingService = new UserIssueTrackingService(log);
        
        log('🔧 Initialized scaling services:');
        log(`   - Token Manager: ${tokenManager.tokens.length} tokens available`);
        log(`   - User Issue Tracking: Enabled`);
        
        // Validate environment variables
        if (tokenManager.tokens.length === 0) {
            throw new Error('No GitHub tokens found. Please configure GITHUB_TOKEN or GITHUB_TOKEN_1-6.');
        }
        
        // Get unique repositories (to avoid duplicate API calls)
        const allRepos = await databases.listDocuments(
            DATABASE_ID,
            COLLECTIONS.REPOSITORIES,
            [
                Query.equal('notifications_enabled', true),
                Query.limit(1000)
            ]
        );
        
        log(`📊 Found ${allRepos.documents.length} repository subscriptions`);
        
        if (allRepos.documents.length === 0) {
            return res.json({
                success: true,
                message: 'No repositories to process',
                timestamp: new Date().toISOString(),
                executionTime: Date.now() - startTime
            });
        }
        
        // Group repositories by owner/name to avoid duplicate API calls
        const uniqueRepos = new Map();
        for (const repo of allRepos.documents) {
            const repoKey = `${repo.repo_owner}/${repo.repo_name}`;
            if (!uniqueRepos.has(repoKey)) {
                uniqueRepos.set(repoKey, repo);
            }
        }
        
        log(`🔗 Processing ${uniqueRepos.size} unique repositories`);
        
        // Process each unique repository
        const results = [];
        let totalNotifications = 0;
        let successCount = 0;
        let errorCount = 0;
        
        for (const [repoKey, repo] of uniqueRepos) {
            const result = await processRepository(repo, tokenManager, trackingService);
            results.push(result);
            
            if (result.success) {
                successCount++;
                totalNotifications += result.newNotifications;
            } else {
                errorCount++;
            }
        }
        
        const executionTime = Date.now() - startTime;
        const tokenStatus = tokenManager.getStatus();
        
        log('🎉 Enhanced GitHub issue polling completed successfully!');
        log(`📊 Summary: ${successCount} successful, ${errorCount} failed, ${totalNotifications} total notifications sent`);
        log(`⏱️  Execution time: ${executionTime}ms`);
        log('🔑 Token Status:');
        tokenStatus.forEach(token => {
            log(`   - ${token.name}: ${token.remaining} remaining, ${token.isActive ? 'active' : 'inactive'}`);
        });
        
        return res.json({
            success: true,
            message: `Processed ${uniqueRepos.size} unique repositories`,
            stats: {
                totalRepositorySubscriptions: allRepos.documents.length,
                uniqueRepositories: uniqueRepos.size,
                successfulRepositories: successCount,
                failedRepositories: errorCount,
                totalNotifications: totalNotifications,
                executionTime: executionTime
            },
            tokenStatus: tokenStatus,
            results: results,
            timestamp: new Date().toISOString()
        });
        
    } catch (error) {
        const executionTime = Date.now() - startTime;
        
        log(`❌ Enhanced GitHub issue polling failed: ${error.message}`);
        log(`⏱️  Execution time: ${executionTime}ms`);
        
        return res.json({
            success: false,
            error: error.message,
            timestamp: new Date().toISOString(),
            executionTime: executionTime
        }, 500);
    }
};
